create definer = rdsadmin@localhost trigger block_user_i
    before insert
    on user
    for each row
block_user: BEGIN
   IF new.User = "rdsadmin" THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT CREATE RDSADMIN USER';
   END IF;

   IF new.User = "rdsrepladmin" THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT CREATE RDSREPLADMIN USER';
   END IF;

   IF new.Host = "localhost" AND (new.User = "mysql.session" OR new.User = "mysql.sys" OR new.User = "mysql.infoschema") THEN
      LEAVE block_user;
   END IF;
   IF new.super_priv = 'Y' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'SUPER PRIVILEGE CANNOT BE GRANTED';
   ELSEIF new.shutdown_priv = 'Y' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'SHUTDOWN PRIVILEGE CANNOT BE GRANTED. PLEASE USE RDS API';
   ELSEIF new.file_priv = 'Y' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'FILE PRIVILEGE CANNOT BE GRANTED';
   ELSEIF new.create_tablespace_priv = 'Y' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CREATE TABLESPACE PRIVILEGE CANNOT BE GRANTED';
   END IF;
END;

